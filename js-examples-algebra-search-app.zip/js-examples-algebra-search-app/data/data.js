export const lectures = [
  {
    lectureName: "HTML",
    lectureLength: 90,
  },
  {
    lectureName: "CSS",
    lectureLength: 120,
  },
  {
    lectureName: "JavaScript",
    lectureLength: 90,
  },
  {
    lectureName: "GIT",
    lectureLength: 80,
  },
  {
    lectureName: "React",
    lectureLength: 10,
  },
  {
    lectureName: "Next.js",
    lectureLength: 190,
  },
  {
    lectureName: "PHP",
    lectureLength: 190,
  },
  {
    lectureName: "Tin.java.js",
    lectureLength: 190,
  },
];
